package com.example.componentlogin;

public interface OnLoginListener
{
    void onLogin(String usuario, String password);
}